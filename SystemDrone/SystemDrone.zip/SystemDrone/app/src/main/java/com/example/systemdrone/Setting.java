package com.example.systemdrone;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Setting extends AppCompatActivity {
    private Button add;
    private TextView mode, date, time, mode2, date2, time2, mode3, date3, time3;
    private EditText editText, editText2;
    private String selitem;
    private Spinner spinner;
    private boolean a,b,c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        add = (Button) findViewById(R.id.add);
        mode = (TextView) findViewById(R.id.mode);
        mode2 = (TextView) findViewById(R.id.mode2);
        mode3 = (TextView) findViewById(R.id.mode3);
        date = (TextView) findViewById(R.id.date);
        date2 = (TextView) findViewById(R.id.date2);
        date3 = (TextView) findViewById(R.id.date3);
        time = (TextView) findViewById(R.id.time);
        time2 = (TextView) findViewById(R.id.time2);
        time3 = (TextView) findViewById(R.id.time3);
        editText = (EditText) findViewById(R.id.editText);
        editText2 = (EditText) findViewById(R.id.editText2);
        spinner = (Spinner) findViewById(R.id.spinner);
        a=false;
        b=false;
        c=false;
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.mode_array, android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }


    public void onAdd(View view) {
        if (date.getText().toString().equals("날짜")) {
            date.setText(editText.getText().toString());
            time.setText(editText2.getText().toString());
            selitem = (String) spinner.getSelectedItem();
            mode.setText(selitem.toString());
        } else if (date2.getText().toString().equals("날짜")) {
            date2.setText(editText.getText().toString());
            time2.setText(editText2.getText().toString());
            selitem = (String) spinner.getSelectedItem();
            mode2.setText(selitem.toString());
        } else if (date3.getText().toString().equals("날짜")) {
            date3.setText(editText.getText().toString());
            time3.setText(editText2.getText().toString());
            selitem = (String) spinner.getSelectedItem();
            mode3.setText(selitem.toString());
        } else
            Toast.makeText(getApplicationContext(), "목록이 꽉 찾습니다.", Toast.LENGTH_SHORT).show();
    }


    public void onDelete(View view) {
        if(a==true){
            mode.setText("모드");
            date.setText("날짜");
            time.setText("시간");
        }
        if(b==true){
            mode2.setText("모드");
            date2.setText("날짜");
            time2.setText("시간");
        }
        if(c==true){
            mode3.setText("모드");
            date3.setText("날짜");
            time3.setText("시간");
        }
    }
    public void onCheckbox(View view) {
        boolean checked = ((CheckBox)view).isChecked();
        switch (view.getId()){
            case R.id.one:
                if(checked)
                    a=true;
                else
                    a=false;
                break;
            case R.id.two:
                if(checked)
                    b=true;
                else
                    b=false;
                break;
            case R.id.three:
                if(checked)
                    c=true;
                else
                    c=false;
                break;
        }
    }
}
