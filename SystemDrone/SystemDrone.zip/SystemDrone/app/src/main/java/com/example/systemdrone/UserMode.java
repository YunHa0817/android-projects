package com.example.systemdrone;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class UserMode extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usermode);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.logoutmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch(item.getItemId())
        {
            case R.id.logout:
                Intent intent = new Intent(getApplicationContext(), Logout.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    public void onClick(View view)
    {
        Intent intent = null;

        switch (view.getId())
        {
            case R.id.setup:
                intent = new Intent(getApplicationContext(), Setting.class);
                break;
            case R.id.weather:
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.kma.go.kr"));
                break;
            case R.id.fvwater:
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://rawris.ekr.or.kr/selectWaterQualityList.do"));
                break;
            case R.id.dronemarket:
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://korean.alibaba.com/trade/search?fsb=y&IndexArea=product_en&CatId=&SearchText=drone&viewtype="));
                break;
            case R.id.fvmarket:
                intent = new Intent(getApplicationContext(), Farming.class);
                break;
        }

        if(intent != null)
        {
            startActivity(intent);
        }
    }
}
