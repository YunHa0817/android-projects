package com.example.systemdrone;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.strictmode.SqliteObjectLeakedViolation;

import java.util.ArrayList;

public class DBSignup extends SQLiteOpenHelper {
    public static final String DATABASS_NAME = "Signup.db";
    public static final String SIGNUP_TABLE_NAME = "signup";
    public static final String SIGNUP_COLUMN_NUMBER = "number";
    public static final String SIGNUP_COLUMN_NAME = "name";
    public static final String SIGNUP_COLUMN_USEREMAIL = "email";
    public static final String SIGNUP_COLUMN_USERID = "id";
    public static final String SIGNUP_COLUMN_USERPWD = "pwd";

    public DBSignup(Context context)
    {
        super(context, DATABASS_NAME, null, 1);
    }

    //DB 테이블 생성
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table signup " + "(number integer primary key, name text, email text, id text, pwd text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS signup");
        onCreate(db);

    }

    public boolean insertSignup(String name, String email, String id, String pwd)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("name", name);
        contentValues.put("email", email);
        contentValues.put("id", id);
        contentValues.put("pwd", pwd);

        db.insert("signup", null, contentValues);
        return true;
    }

    public Cursor getData(int id)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from signup where id=" + id + "", null);
        return res;
    }

    public int numberOfRows()
    {
        SQLiteDatabase db = this.getReadableDatabase();

        int numRows = (int) DatabaseUtils.queryNumEntries(db, SIGNUP_TABLE_NAME);
        return numRows;
    }

    public boolean updateSignup(Integer number, String name, String email, String id, String pwd)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("email", email);
        contentValues.put("id", id);
        contentValues.put("pwd", pwd);
        db.update("signup", contentValues, "id = ?", new String[] {Integer.toString(number)});
        return true;
    }

    public Integer deleteMovie(Integer number)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("signup", "id = ?", new String[] {Integer.toString(number)});
    }

    public ArrayList getAllMovices()
    {
        ArrayList array_list = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from signup", null);
        res.moveToFirst();
        while (res.isAfterLast() == false)
        {
            array_list.add(res.getString(res.getColumnIndex(SIGNUP_COLUMN_NAME)));
            res.moveToNext();
        }
        return array_list;
    }
}
