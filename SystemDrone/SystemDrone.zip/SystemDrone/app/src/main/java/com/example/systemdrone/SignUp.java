package com.example.systemdrone;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignUp extends AppCompatActivity {
    private DBSignup dbSignup;
    EditText suName;
    EditText suEmail;
    EditText suID;
    EditText suPW1;
    EditText suPW2;
    int id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        suName = (EditText)findViewById(R.id.su_Name);
        suID = (EditText)findViewById(R.id.su_ID);
        suEmail = (EditText)findViewById(R.id.su_Email);
        suPW1 = (EditText)findViewById(R.id.su_Pw1);
        suPW2 = (EditText)findViewById(R.id.su_Pw2);

        dbSignup = new DBSignup(this);
        Bundle extras = getIntent().getExtras();

        if(extras != null)
        {
            int Value = extras.getInt("id");
            if(Value > 0)
            {
                Cursor rs = dbSignup.getData(Value);
                id = Value;
                rs.moveToFirst();

                String name = rs.getString(rs.getColumnIndex(DBSignup.SIGNUP_COLUMN_NAME));
                String email = rs.getString(rs.getColumnIndex(DBSignup.SIGNUP_COLUMN_USEREMAIL));
                String id = rs.getString(rs.getColumnIndex(DBSignup.SIGNUP_COLUMN_USERID));
                String pwd = rs.getString(rs.getColumnIndex(DBSignup.SIGNUP_COLUMN_USERPWD));

                if(!rs.isClosed())
                {
                    rs.close();
                }

                Button btn = (Button)findViewById(R.id.signupsubmit);
                btn.setVisibility(View.INVISIBLE);

                suName.setText((CharSequence)name);
                suEmail.setText((CharSequence)email);
                suID.setText((CharSequence)id);
                suPW1.setText((CharSequence)pwd);
            }
        }

        suPW2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String pw1 = suPW1.getText().toString();
                String pw2 = suPW2.getText().toString();

                if(pw1.equals(pw2))
                {
                    suPW2.setBackgroundColor(Color.GREEN);
                    Toast.makeText(getApplicationContext(), "비밀번호 일치 합니다.", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    suPW2.setBackgroundColor(Color.RED);
                    Toast.makeText(getApplicationContext(), "비밀번호 다시 입력하세요.", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    public void insert(View view)
    {
        Bundle extras = getIntent().getExtras();

        if(extras != null)
        {
                if(dbSignup.insertSignup(suName.getText().toString(), suEmail.getText().toString(), suID.getText().toString(), suPW1.getText().toString()))
                {
                    if(suName.getText().toString().equals("") || suEmail.getText().toString().equals("") || suID.getText().toString().equals("") || suPW1.getText().toString().equals(""))
                    {
                        Toast.makeText(getApplicationContext(), "회원가입 누락된 항목을 입력해 주세요!!!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "회원가입 완료", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "회원가입 실패", Toast.LENGTH_SHORT).show();
                }
        }
    }
}
