package com.example.systemdrone;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView myListView;
    DBSignup signupdb;
    ArrayAdapter mAdapter;
    EditText userID;
    EditText userPW;
    CheckBox idSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userID = (EditText)findViewById(R.id.userid);
        userPW = (EditText)findViewById(R.id.userpw1);
        idSave = (CheckBox)findViewById(R.id.autologin);
        signupdb = new DBSignup(this);

        ArrayList array_list = signupdb.getAllMovices();
        mAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, array_list);




        //SharedPreferences pref = getSharedPreferences("pref", Activity.MODE_PRIVATE);
        //String id = pref.getString("id", "");
        //Boolean chk1 = pref.getBoolean("chk1", false);

        //if(chk1 == true)
        //{
            //userID.setText(id);
            //idSave.setChecked(chk1);
        //}
    }

    @Override
    public void onResume()
    {
        super.onResume();
        mAdapter.clear();
        mAdapter.addAll(signupdb.getAllMovices());
        mAdapter.notifyDataSetChanged();
    }

    public void onClick(View view)
    {
        Bundle bundle = new Bundle();
        bundle.putInt("id", 0);

        Intent intent = null;
        switch (view.getId())
        {
            case R.id.login:
                intent = new Intent(getApplicationContext(), UserMode.class);
                break;
            case R.id.signup:
                intent = new Intent(getApplicationContext(), SignUp.class);
                intent.putExtras(bundle);
                break;
        }
        if(intent != null)
            startActivity(intent);
    }

    public void login(View view)
    {
    }
}
